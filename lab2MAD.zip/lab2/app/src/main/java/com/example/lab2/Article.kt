package com.example.lab2

class Article(
    var title: String,
    var date: String,
    var image: Int,
    var details: String
)
