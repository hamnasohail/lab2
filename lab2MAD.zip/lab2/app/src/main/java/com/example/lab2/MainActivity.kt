package com.example.lab2
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerview: RecyclerView = findViewById(R.id.recyclerview)

        val adapter = ArticlesAdapter(getArticles())
        recyclerview.adapter=adapter
        val manager=LinearLayoutManager(this)
        recyclerview.layoutManager= manager
    }

    fun getArticles(): List<Article> {
        val articles = ArrayList<Article>()

        articles.add(Article("All chocolate cake", "September 24, 2024", R.drawable.image1, "A rich, decadent all-chocolate cake perfect for every chocolate lover."))
        articles.add(Article("Vanilla cake", "Date 2, 2024", R.drawable.image2, "A light, fluffy vanilla cake with layers of sweetness and simplicity."))
        articles.add(Article("Red velvet cake", "Date 3, 2024", R.drawable.image3, "A classic red velvet cake with a smooth cream cheese frosting."))
        articles.add(Article("Chocolate and caramel cake", "Date 4, 2024", R.drawable.image4, "A deliciously rich cake combining chocolate and caramel in every bite."))
        articles.add(Article("Raspberry Ripple cake", "Date 5, 2024", R.drawable.image5, "This raspberry ripple cake offers a fruity twist to a moist vanilla base."))
        articles.add(Article("Lemon Berry cake", "Date 6, 2024", R.drawable.image6, "Citrusy and refreshing, this lemon berry cake is a delightful treat for summer."))
        articles.add(Article("Chocolate and berry Cake", "Date 7, 2024", R.drawable.image7, "A decadent chocolate cake combined with fresh berries for an indulgent dessert."))
        articles.add(Article("Mocha Cake", "Date 8, 2024", R.drawable.image8, "A coffee lover’s dream, this mocha cake balances rich chocolate and coffee flavors."))
        articles.add(Article("Bento cakes", "Date 9, 2024", R.drawable.image9, "Cute, single-serving bento cakes decorated with minimalist designs."))
        articles.add(Article("Vintage Cake", "Date 10, 2024", R.drawable.image10, "A retro-style vintage cake, featuring nostalgic decorations and flavors."))
        articles.add(Article("Wedding Cake", "Date 11, 2024", R.drawable.image11, "An elegant multi-tiered wedding cake, perfect for celebrating a special day."))
        articles.add(Article("Father's birthday Cake", "Date 12, 2024", R.drawable.image12, "A cake designed with dads in mind, rich in flavor and beautifully decorated."))
        articles.add(Article("Flowers Theme Cake", "Date 13, 2024", R.drawable.image13, "A floral-themed cake with edible flowers and delicate designs for a spring celebration."))
        articles.add(Article("Strawberry Classic Cake", "Date 14, 2024", R.drawable.image14, "A strawberry cake with fresh layers of strawberry filling and buttercream."))
        articles.add(Article("Macaron Cake", "Date 15, 2024", R.drawable.image15, "A cake adorned with colorful macarons, perfect for any celebration."))
        articles.add(Article("Chocolate Cake", "Date 16, 2024", R.drawable.image1, "A simple yet delicious classic chocolate cake for all occasions."))
        articles.add(Article("Strawberry Cake", "Date 17, 2024", R.drawable.image7, "Fresh strawberry cake made with layers of strawberry puree and frosting."))
        articles.add(Article("Red Velvet Cake", "Date 18, 2024", R.drawable.image5, "Another red velvet cake with velvety texture and cream cheese frosting."))
        articles.add(Article("Butterfly Cake", "Date 19, 2024", R.drawable.image6, "A beautiful butterfly-themed cake decorated with delicate wings and vibrant colors."))
        articles.add(Article("Vanilla Cake", "Date 20, 2024", R.drawable.image2, "A classic vanilla cake with soft layers and rich vanilla buttercream."))

        return articles
    }

}