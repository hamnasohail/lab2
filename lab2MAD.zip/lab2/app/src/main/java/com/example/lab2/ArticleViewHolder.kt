package com.example.lab2

import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.TextView


class ArticleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
val image:ImageView= itemView.findViewById(R.id.image5)
    val text:TextView= itemView.findViewById(R.id.title5)

}
